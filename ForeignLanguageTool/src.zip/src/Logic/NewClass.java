/*
File: NewClass.java
Author: Ethan Swistak
Date: Jun 30, 2019
Purpose:
*/

package Logic;


public class NewClass {

}
